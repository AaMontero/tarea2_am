package com.example.animenews.ui.activities

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.preference.PreferenceManager
import com.example.animenews.ResultActivity
import com.example.animenews.data.entidades.AnimeItem
import com.example.animenews.databinding.ActivityShowItemBinding
import com.squareup.picasso.Picasso
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

class ShowItemActivity : AppCompatActivity() {

    private lateinit var binding: ActivityShowItemBinding
    private lateinit var item1: AnimeItem

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityShowItemBinding.inflate(layoutInflater)
        setContentView(binding.root)

        intent.extras?.let {
            item1 = Json.decodeFromString(it.get("item").toString()) as AnimeItem
        }

        ShowInitItem()
        val respuesta = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
            //it.resultCode == RESULT_OK
            //it.resultCode == RESULT_CANCELED

            if(it.resultCode == RESULT_OK){
                val message = it.data?.getStringExtra("val")
                binding.itemTitle.text = message
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            }


        }
        binding.btnCompartir.setOnClickListener {
            //ShareItem()
            //Se detalla cual es el sharedPreference que se va a utilizar
            //funcion()
            //ActivityForTResult
            respuesta.launch(Intent(this, ResultActivity::class.java))

        }
    }
    private fun funcion(){
        val publicShare = applicationContext.getSharedPreferences(
            "sesiones",
            Context.MODE_PRIVATE
        )

        val edit = publicShare.edit()
        edit.putString("nombre", "Anthonny")
        edit.putString("apellido","Aguilar")
        edit.apply()

        /*with(publicShare.edit()){
            putString("nombre", "Anthonny")
            putString("nombre", "Alexander")
            putString("nombre", "Daniel ")
        }.apply()*/

        val activityShare = PreferenceManager.getDefaultSharedPreferences(this)
        with(activityShare.edit()){
            putString("nombre", "Alexander")
            putString("apellido", "Montero")
            putString("segundoNombre", "Daniel ")
        }.apply()
        //put - Guardar, remove - Eliminar, clear - Limpiar, get - recuperar (String, String?)
        activityShare.edit()



        val a = publicShare.getString("nombre", "Dato Inexistente")
        val b = activityShare.getString("nombre", "Dato Inexistente")

        Log.d("UCE" , a.toString())
        Log.d("UCE" , b.toString())
    }
    private fun ShareItem() {

        /*
        Intent explicit
          var intent = Intent(this, LoginActivity::class.java)
          intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
          intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
          startActivity(intent)

         Intent View (implicit)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("https://www.tutorialkart.com/")
            }
            startActivity(intent)

         Intent Share (implicit)
            val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, item1.toString())
                type = "text/plain"
            }
            startActivity(intent)
         */

        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, item1.name.toString())
            type = "text/plain"
        }
        startActivity(sendIntent)
    }

    private fun ShowInitItem() {
        Picasso.get().load(item1.photo).into(binding.itemPhoto)
        binding.itemTitle.text = item1.name
    }
}